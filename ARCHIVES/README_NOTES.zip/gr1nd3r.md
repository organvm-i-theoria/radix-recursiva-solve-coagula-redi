# GR1ND3R
**UID**: `GR01`  
**Folder**: `gr1nd3r`

---

### 🧠 Purpose:
psych horror / dread aesthetic

---

### 🧵 Linked Threads:
_TODO: Populate with thread summaries or GPT-generated digests._

---

### 📌 Notes:
- [ ] Merge candidates?
- [ ] Style rules?
- [ ] Vault naming logic?

---

**Status**: `📂 Folder initialized`  
