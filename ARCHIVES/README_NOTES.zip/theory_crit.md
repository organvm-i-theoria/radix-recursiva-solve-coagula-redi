# THEORY__CR1T
**UID**: `TC01`  
**Folder**: `theory_crit`

---

### 🧠 Purpose:
academic theory / critique / reflection

---

### 🧵 Linked Threads:
_TODO: Populate with thread summaries or GPT-generated digests._

---

### 📌 Notes:
- [ ] Merge candidates?
- [ ] Style rules?
- [ ] Vault naming logic?

---

**Status**: `📂 Folder initialized`  
