# INTR4__Z0N3
**UID**: `IZ01`  
**Folder**: `intr4_z0ne`

---

### 🧠 Purpose:
thresholds / liminality / edges

---

### 🧵 Linked Threads:
_TODO: Populate with thread summaries or GPT-generated digests._

---

### 📌 Notes:
- [ ] Merge candidates?
- [ ] Style rules?
- [ ] Vault naming logic?

---

**Status**: `📂 Folder initialized`  
