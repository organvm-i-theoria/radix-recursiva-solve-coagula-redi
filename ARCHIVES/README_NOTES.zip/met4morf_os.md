# MET4morfoses
**UID**: `MT01`  
**Folder**: `met4morf_os`

---

### 🧠 Purpose:
speculative fiction / transformation

---

### 🧵 Linked Threads:
_TODO: Populate with thread summaries or GPT-generated digests._

---

### 📌 Notes:
- [ ] Merge candidates?
- [ ] Style rules?
- [ ] Vault naming logic?

---

**Status**: `📂 Folder initialized`  
