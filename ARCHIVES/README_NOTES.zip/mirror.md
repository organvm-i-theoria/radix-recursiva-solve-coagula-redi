# M1RR0R
**UID**: `MR01`  
**Folder**: `mirror`

---

### 🧠 Purpose:
shadow self / double / inner critic

---

### 🧵 Linked Threads:
_TODO: Populate with thread summaries or GPT-generated digests._

---

### 📌 Notes:
- [ ] Merge candidates?
- [ ] Style rules?
- [ ] Vault naming logic?

---

**Status**: `📂 Folder initialized`  
