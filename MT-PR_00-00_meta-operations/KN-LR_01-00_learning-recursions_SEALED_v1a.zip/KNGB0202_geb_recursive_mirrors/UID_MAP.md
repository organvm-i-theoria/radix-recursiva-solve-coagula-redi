# UID_MAP for KNGB0202

| UID       | File Name           | Description                         |
|-----------|---------------------|-------------------------------------|
| KNGB0202     | README.md           | Agent overview and symbolic logic   |
| KNGB0202     | MYTH_AGENT.md       | Invocation pattern and identity     |
| KNGB0202     | SYMB0L_FUSION.md    | Integration with MIRROR_CHAMBER     |
