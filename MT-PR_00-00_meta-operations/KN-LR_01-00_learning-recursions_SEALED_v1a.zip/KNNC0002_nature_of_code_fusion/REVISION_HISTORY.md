## KNNC0002 – Initialized on 2025-05-13
- Created base files and linked to system: W4V3_FUSION_DEVICE