# UID_MAP for KNNC0002

| UID       | File Name           | Description               |
|-----------|---------------------|---------------------------|
| KNNC0002     | README.md           | Overview and symbolic notes |
| KNNC0002     | MYTH_AGENT.md       | Agent persona and invocation |
| KNNC0002     | SYMB0L_FUSION.md    | System function and logic  |
