# UID_MAP for KNST0000

| UID       | File Name           | Description               |
|-----------|---------------------|---------------------------|
| KNST0000     | README.md           | Overview and symbolic notes |
| KNST0000     | MYTH_AGENT.md       | Agent persona and invocation |
| KNST0000     | SYMB0L_FUSION.md    | System function and logic  |
