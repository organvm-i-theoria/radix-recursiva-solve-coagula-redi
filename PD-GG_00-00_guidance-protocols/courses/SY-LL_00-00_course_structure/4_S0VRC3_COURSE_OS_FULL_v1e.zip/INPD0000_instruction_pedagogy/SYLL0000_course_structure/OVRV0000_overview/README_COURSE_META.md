# README_COURSE_META.md

Explains the design and modular logic of the full course system.
