# MODULE_STRUCTURE_GUIDE.md

Explains how to build and deploy modular writing units.
