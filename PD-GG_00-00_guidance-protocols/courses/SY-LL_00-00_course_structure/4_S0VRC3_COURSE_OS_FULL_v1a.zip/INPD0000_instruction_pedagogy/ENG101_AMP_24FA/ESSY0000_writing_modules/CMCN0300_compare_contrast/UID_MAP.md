# UID Map – Compare & Contrast (CMCN_03)

| UID         | Section/Prompt                      | Notes |
|-------------|--------------------------------------|-------|
| CMCN_03-01 | Warm-up Reflection               |                |
| CMCN_03-02 | Structure / Mapping Scaffold     |                |
| CMCN_03-03 | Thesis Builder / Outline         |                |
| CMCN_03-04 | Peer Review / Checklist          |                |
| CMCN_03-00 | Folder UID / System Tag          | Always ends in `00` |
