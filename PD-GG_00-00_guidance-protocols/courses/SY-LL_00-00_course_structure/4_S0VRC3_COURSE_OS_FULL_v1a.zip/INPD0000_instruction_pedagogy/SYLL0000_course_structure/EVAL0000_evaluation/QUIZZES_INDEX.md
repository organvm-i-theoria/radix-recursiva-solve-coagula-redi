# QUIZZES_INDEX.md

Optional reading/symbol/structure quizzes with UID references.
