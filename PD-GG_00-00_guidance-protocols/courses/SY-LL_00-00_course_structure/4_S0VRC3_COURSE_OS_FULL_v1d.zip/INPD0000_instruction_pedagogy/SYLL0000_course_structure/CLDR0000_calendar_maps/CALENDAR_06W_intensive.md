# CALENDAR_06W_intensive.md

Timeline for intensive 6-week version.
