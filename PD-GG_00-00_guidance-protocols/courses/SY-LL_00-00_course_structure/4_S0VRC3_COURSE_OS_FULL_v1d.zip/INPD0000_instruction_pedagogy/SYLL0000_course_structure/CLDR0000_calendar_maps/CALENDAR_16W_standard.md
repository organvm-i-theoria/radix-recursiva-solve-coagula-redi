# CALENDAR_16W_standard.md

Timeline for 16-week version of the course.
