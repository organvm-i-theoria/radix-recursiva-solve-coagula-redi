# FINAL_PROJECT_PROMPT.md

End-of-course synthesis project + upload instructions.
