# UID Map – Argument Essay (ARRG_04)

| UID         | Section/Prompt                      | Notes |
|-------------|--------------------------------------|-------|
| ARRG_04-01 | Warm-up Reflection               |                |
| ARRG_04-02 | Structure / Mapping Scaffold     |                |
| ARRG_04-03 | Thesis Builder / Outline         |                |
| ARRG_04-04 | Peer Review / Checklist          |                |
| ARRG_04-00 | Folder UID / System Tag          | Always ends in `00` |
