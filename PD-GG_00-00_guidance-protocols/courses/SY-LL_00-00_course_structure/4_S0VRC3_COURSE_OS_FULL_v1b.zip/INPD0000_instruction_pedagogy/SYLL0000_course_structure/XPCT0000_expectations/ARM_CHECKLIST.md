# ARM_CHECKLIST.md

Weekly tracker for Attendance, Reading, and Mindset submissions.
