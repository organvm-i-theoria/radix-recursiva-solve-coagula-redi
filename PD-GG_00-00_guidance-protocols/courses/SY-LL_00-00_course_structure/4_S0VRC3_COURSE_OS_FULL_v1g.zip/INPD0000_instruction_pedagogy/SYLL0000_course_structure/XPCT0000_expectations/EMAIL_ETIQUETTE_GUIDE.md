# EMAIL_ETIQUETTE_GUIDE.md

Sample email templates, tone expectations, and communication tips.
