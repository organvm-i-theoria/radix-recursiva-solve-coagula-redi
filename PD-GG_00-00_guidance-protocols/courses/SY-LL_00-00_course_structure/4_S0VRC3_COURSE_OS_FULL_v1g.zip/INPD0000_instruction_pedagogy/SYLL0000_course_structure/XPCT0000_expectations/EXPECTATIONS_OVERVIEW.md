# EXPECTATIONS_OVERVIEW.md

Student-facing list of behavioral and academic expectations.
