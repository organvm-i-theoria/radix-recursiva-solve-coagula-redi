# SOP_SETUP.md

How to initialize and configure the 4_S0VRC3 system from a clean export.
