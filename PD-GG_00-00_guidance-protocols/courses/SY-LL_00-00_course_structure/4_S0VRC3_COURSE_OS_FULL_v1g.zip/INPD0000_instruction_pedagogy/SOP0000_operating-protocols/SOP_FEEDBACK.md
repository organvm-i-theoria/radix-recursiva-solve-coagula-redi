# SOP_FEEDBACK.md

How to use the UID feedback system, ChatGPT, and batch folder methods to deliver high-level responses.
