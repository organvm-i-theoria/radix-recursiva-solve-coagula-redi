# SOP_EXPANSION.md

How to fork this system for another course (ENG201, LIT104, CWX101, etc.).
