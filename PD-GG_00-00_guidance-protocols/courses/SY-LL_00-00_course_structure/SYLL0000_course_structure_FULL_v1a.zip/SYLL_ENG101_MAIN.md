# SYLL_ENG101_MAIN.md

Master syllabus with module layout, dates, and policies.
