# CALENDAR_12W_accelerated.md

Timeline for 12-week accelerated format.
