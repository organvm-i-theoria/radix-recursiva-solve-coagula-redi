# README_DEPLOYMENT.md

Instructions for deploying this system into new terms or courses.
