# MODULE_TEMPLATE_ALT.md

Alternate project template (media, fieldwork, remix).
