# GRADING_BREAKDOWN.md

How grading works across essays, reflections, and UID checklists.
