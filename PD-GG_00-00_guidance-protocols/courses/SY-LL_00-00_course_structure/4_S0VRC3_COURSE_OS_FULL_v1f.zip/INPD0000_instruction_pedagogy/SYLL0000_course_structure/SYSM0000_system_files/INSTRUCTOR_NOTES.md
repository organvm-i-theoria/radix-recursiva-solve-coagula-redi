# INSTRUCTOR_NOTES.md

Internal observations, semester-to-semester notes, teaching patterns.
