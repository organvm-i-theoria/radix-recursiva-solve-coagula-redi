# ANNOTATION_GUIDE.md

How to annotate readings using symbolic or digital strategies.
