# LATE_WORK_POLICY.md

Clear expectations for late work and UID-linked exception pathing.
