# SYST0002_course-site-map

This document represents the symbolic, structural, and navigational plan for expanding the ENG101 UID-governed OS into a mobile- and web-accessible learning environment.

## Primary Web URL (placeholder)
**Root:** https://creative-composition-systems.URL

## Logical Site Structure
This structure mirrors the OS folder UID tree and allows future reuse for other courses (ENG201, LIT104, etc.).

### Root Pages
| Web Path         | Maps To Folder UID       | Description                             |
|------------------|--------------------------|-----------------------------------------|
| `/`              | SYLL0000                 | Syllabus, calendar, expectations        |
| `/narrative`     | NRTV0100                 | Unit 1: Narrative Essay                 |
| `/process`       | PRNS0200                 | Unit 2: Process Analysis                |
| `/compare`       | CMCN0300                 | Unit 3: Compare/Contrast                |
| `/argument`      | ARRG0400                 | Unit 4: Argument Essay                  |
| `/portfolio`     | PFRT0500                 | Unit 5: Final Portfolio                 |
| `/submit`        | SYSTEM                   | Upload portal for assignment delivery   |
| `/uids`          | UID registry             | Full UID lookup / glossary             |
| `/toolkit`       | SYLL/UTIL                | Downloads, checklists, zip bundles     |
| `/system`        | SYST0000 + SYSM0001      | System overview, rubric map, author log|

### Future Logic
- Each `/unit` page includes: overview, warm-up, scaffold, download, and submission form
- UID tagging becomes anchor links in-page (e.g., `#CMCN_03-03`)
- Obsidian Publish, Notion, or static site generator (Svelte/NextJS) possible
- Instructor mode = view UID logs, feedback summaries, tool access

## Course Path Conventions
| Course         | Base Path               |
|----------------|-------------------------|
| ENG101         | `/` (default index)     |
| LIT104         | `/lit104/`              |
| ENG201         | `/eng201/`              |

## Recommendations
- Keep all `.md` and UIDs compatible with flat export to Notion, Obsidian Publish, or Netlify.
- Link syllabus and calendar directly from root for onboarding.
- Eventually theme each unit page with color + symbol based on UID prefix (e.g., NRTV = indigo spiral).
