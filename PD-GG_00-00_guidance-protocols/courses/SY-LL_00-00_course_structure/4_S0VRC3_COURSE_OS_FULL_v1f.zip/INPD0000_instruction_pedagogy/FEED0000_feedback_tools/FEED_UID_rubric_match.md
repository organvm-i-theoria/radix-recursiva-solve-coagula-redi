# FEED_UID_rubric_match.md

Map each UID to its associated rubric value and interpretation logic.
