# UID Map – Process Analysis (PRNS_02)

| UID         | Section/Prompt                      | Notes |
|-------------|--------------------------------------|-------|
| PRNS_02-01 | Warm-up Reflection               |                |
| PRNS_02-02 | Structure / Mapping Scaffold     |                |
| PRNS_02-03 | Thesis Builder / Outline         |                |
| PRNS_02-04 | Peer Review / Checklist          |                |
| PRNS_02-00 | Folder UID / System Tag          | Always ends in `00` |
