# UID Map – Final Portfolio (PFRT_05)

| UID         | Section/Prompt                      | Notes |
|-------------|--------------------------------------|-------|
| PFRT_05-01 | Warm-up Reflection               |                |
| PFRT_05-02 | Structure / Mapping Scaffold     |                |
| PFRT_05-03 | Thesis Builder / Outline         |                |
| PFRT_05-04 | Peer Review / Checklist          |                |
| PFRT_05-00 | Folder UID / System Tag          | Always ends in `00` |
