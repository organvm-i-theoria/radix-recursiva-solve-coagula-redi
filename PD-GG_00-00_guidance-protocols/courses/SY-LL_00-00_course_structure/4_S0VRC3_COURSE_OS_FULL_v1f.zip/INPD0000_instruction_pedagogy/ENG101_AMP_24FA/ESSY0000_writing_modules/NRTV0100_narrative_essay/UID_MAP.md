# UID Map – Narrative Essay (NRTV_01)

| UID         | Section/Prompt                      | Notes |
|-------------|--------------------------------------|-------|
| NRTV_01-01 | Warm-up Reflection               |                |
| NRTV_01-02 | Structure / Mapping Scaffold     |                |
| NRTV_01-03 | Thesis Builder / Outline         |                |
| NRTV_01-04 | Peer Review / Checklist          |                |
| NRTV_01-00 | Folder UID / System Tag          | Always ends in `00` |
