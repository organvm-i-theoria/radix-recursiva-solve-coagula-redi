# LECTURE_FRAGMENTS.md

Fragments of lectures, symbolic rants, aesthetic threads.
