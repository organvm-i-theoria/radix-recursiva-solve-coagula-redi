# ENG201_CLONE_INSTRUCTION

## Purpose:
How to duplicate this system for ENG201, LIT104, CWX101, or other courses using the 4_S0VRC3 backbone.

## Steps:

1. **Duplicate Folder**
   - Copy `/ENG101_AMP_24FA/` and rename to `/ENG201_AMP_24SP/`

2. **Update UID Prefixes**
   - Replace `NRTV` with `CLMS`, `CMCN` with `DISS`, etc.
   - Update `UID_MAP.md` and file names accordingly

3. **Edit Readmes**
   - Update all `README.md` files to reflect ENG201 context

4. **Adjust Timeline Maps**
   - Copy or edit from `SYLL0000/CALENDAR_MAPS/` for new term schedule

5. **Confirm SOP + UID Integrity**
   - Run `uid_check.py`
   - Confirm rubric matches new essays

6. **Create New Zip**
   - Run `zip_unit.py ENG201_AMP_24SP`

System ready.
