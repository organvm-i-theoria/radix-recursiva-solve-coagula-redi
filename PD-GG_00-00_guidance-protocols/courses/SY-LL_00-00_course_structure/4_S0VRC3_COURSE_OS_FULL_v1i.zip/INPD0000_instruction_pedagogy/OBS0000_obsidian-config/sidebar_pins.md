# Pinned Pages (Obsidian)

- [[homepage]]
- [[_index]]
- [[SYLL0000_course_structure/OVRV0000_overview/README_COURSE_META.md]]
- [[ENG101_AMP_24FA/ESSY0000_writing_modules/CMCN0300_compare_contrast/UID_MAP.md]]
- [[FEED0000_feedback_tools/FEED_TEMPLATE_letter.md]]