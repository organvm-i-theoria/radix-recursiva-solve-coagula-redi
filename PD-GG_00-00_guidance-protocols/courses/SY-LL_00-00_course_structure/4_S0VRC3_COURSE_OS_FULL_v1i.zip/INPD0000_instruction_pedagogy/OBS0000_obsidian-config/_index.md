# Course Vault Index

This is the central index of all UID-governed course materials.

- [SYLL0000 – Course Structure](../SYLL0000_course_structure/)
- [ESSY0000 – Essay Units](../ENG101_AMP_24FA/ESSY0000_writing_modules/)
- [FEED0000 – Feedback Tools](../FEED0000_feedback_tools/)
- [UTIL0000 – Utility Scripts](../UTIL0000_course_tools/)
- [SYST – Symbolic System](../SYST0000_symbolic-overview.md)