# Welcome to the UID-Structured Course Vault

This Obsidian vault contains all modules, assignments, tools, feedback workflows, and symbolic architecture for ENG101.

Use the left-hand nav or search UIDs like `CMCN_03-04` to navigate.

**Start with:**
- [README_COURSE_META](../SYLL0000_course_structure/OVRV0000_overview/README_COURSE_META.md)
- [Dashboard](../README_LAUNCH_DASHBOARD.md)
- [UID Constitution](../SYST0000_symbolic-overview.md)