# SOP_EXPORT.md

Step-by-step protocol for preparing and exporting the course OS for LMS or ZIP.
