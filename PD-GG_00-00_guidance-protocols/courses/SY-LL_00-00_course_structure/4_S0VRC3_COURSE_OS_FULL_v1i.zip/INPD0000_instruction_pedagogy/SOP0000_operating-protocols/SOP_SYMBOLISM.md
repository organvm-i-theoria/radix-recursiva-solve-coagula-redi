# SOP_SYMBOLISM.md

A guide to interpreting the symbolic structures inside the UID, folder logic, and metaphor system.
