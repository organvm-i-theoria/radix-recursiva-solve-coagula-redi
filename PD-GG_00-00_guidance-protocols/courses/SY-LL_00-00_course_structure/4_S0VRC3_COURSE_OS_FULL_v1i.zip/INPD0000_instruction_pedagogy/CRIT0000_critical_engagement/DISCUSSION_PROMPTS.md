# DISCUSSION_PROMPTS.md

Deep, open-ended questions for each essay module. Group or writing prompts.
