# MIDTERM_SCORESHEET.md

Midterm grading breakdown. UID-weighted rubric scaffold.
