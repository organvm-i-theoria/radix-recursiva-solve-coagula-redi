# MODULE_TEMPLATE_4PART.md

4-part scaffold module template: warm-up → scaffold → draft → review.
