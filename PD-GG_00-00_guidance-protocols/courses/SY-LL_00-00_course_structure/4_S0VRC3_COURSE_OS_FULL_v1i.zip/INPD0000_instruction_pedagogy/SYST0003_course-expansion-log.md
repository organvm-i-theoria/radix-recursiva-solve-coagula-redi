# SYST0003_course-expansion-log

This symbolic seed file prepares the foundation for duplicating and adapting the 4_S0VRC3 system for other courses like ENG201, LIT104, or creative writing workshops.

## System Cloning Plan
- Duplicate `ENG101_AMP_24FA` and rename per new course (e.g., `ENG201_AMP_24SP`)
- Update all folder UID prefixes (e.g., `NRTV` → `LTMY`, `CMCN` → `DISS`)
- Refresh `UID_MAP.md` files per essay folder
- Rebuild `SYLL0000/` calendar maps if delivery rhythm changes

## Candidate Courses for Expansion
| Course Code | Title                       | Initial Notes                         |
|-------------|-----------------------------|----------------------------------------|
| `ENG201`    | Advanced Composition         | Build on this system. Add research tools, source logics, and citation scaffolds. |
| `LIT104`    | Intro to Literature          | Use symbolic UID logic. Shorten scaffolds. Add interpretive quizzes + media. |
| `CWX101`    | Creative Writing Studio      | Scaffold workshop cycles. Emphasize symbolic UID prompts and feedback letters. |

## Symbolic Naming Options
- `ENG201` → Seed: `DISS`, `CLMS`, `SYNX`
- `LIT104` → Seed: `LTMY`, `SYMB`, `VNTS`
- `CWX101` → Seed: `STDM`, `BLMF`, `ETC4`

## Next Steps
- After cloning, update `README_LAUNCH_DASHBOARD.md` to match new context
- Consider creating a unified root folder: `4_S0VRC3_COURSES/` to house all courses
- Build symbolic dashboards across all folders and web paths
