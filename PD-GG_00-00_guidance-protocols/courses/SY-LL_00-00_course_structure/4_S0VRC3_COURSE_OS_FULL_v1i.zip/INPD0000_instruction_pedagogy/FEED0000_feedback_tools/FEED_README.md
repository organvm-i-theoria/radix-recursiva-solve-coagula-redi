# FEED_README.md

Explains how to generate feedback using ChatGPT + UID rubric structure.
