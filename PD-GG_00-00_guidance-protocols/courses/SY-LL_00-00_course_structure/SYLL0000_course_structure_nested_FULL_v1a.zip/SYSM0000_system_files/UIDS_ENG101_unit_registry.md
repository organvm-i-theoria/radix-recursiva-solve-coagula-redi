# UIDS_ENG101_unit_registry.md

Full UID registry of every assignment and section in the course.
