# CALENDAR_08W_doubletime.md

Timeline for 8-week double-paced delivery.
