# MIDTERM_PROMPT.md

Mid-semester scaffolded remix project or reflective milestone.
