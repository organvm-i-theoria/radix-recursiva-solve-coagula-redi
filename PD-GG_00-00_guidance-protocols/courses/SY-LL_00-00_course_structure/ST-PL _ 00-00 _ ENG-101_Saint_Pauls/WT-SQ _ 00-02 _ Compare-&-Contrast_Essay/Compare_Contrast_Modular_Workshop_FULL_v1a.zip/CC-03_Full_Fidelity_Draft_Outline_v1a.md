# CC-03 – Full-Fidelity Draft Outline & Essay Builder

### Purpose:
Move from deep comparison into structured drafting using thesis templates and full outline scaffolding.

## Your Thesis
<!-- CM-CN _ 327-328 _ -->
Write a one-sentence thesis that compares *Ponyo* and *The Little Mermaid*, focusing on a theme such as transformation, love, agency, or nature.

**Sentence Starter:**
> “Both *Ponyo* and *The Little Mermaid* explore the theme of __________, but while one emphasizes __________, the other focuses on __________.”
> 
> 

## Essay Outline
<!-- CM-CN _ 329-330 _ -->
Use this space to sketch a basic outline for your essay:

- <!-- CM-CN _ 331-332 _ --> **1. Introduction** – Hook, cultural context, and thesis
- <!-- CM-CN _ 333-334 _ --> **2. Key Similarity or Shared Origin**
- <!-- CM-CN _ 335-336 _ --> **3. Key Cultural or Thematic Difference**
- <!-- CM-CN _ 337-338 _ --> **4. Your Cultural Insight or Perspective**
- <!-- CM-CN _ 339-340 _ --> **5. Conclusion** – Reflection, implications, takeaway

## Essay Map Sample
<!-- CM-CN _ 341-342 _ -->
Use this to guide your essay structure:

1. Introduction — Hook, context, thesis
2. Body Paragraph 1 — Main point + both film examples
3. Body Paragraph 2 — Second point + both films again, tension/counterexample/synthesis
4. Cultural Reflection — Your own insight and context
5. Conclusion — Restate insight, raise final question or broader meaning