# CC-02B – Full-Fidelity Triadic Comparison (Blocks 2–3)

## Ocean as Setting and Symbol
### Ponyo
<!-- CM-CN _ 091-092 _ -->
- How does the ocean behave—does it feel alive or symbolic?
> 
> 

<!-- CM-CN _ 093-094 _ -->
- How are ocean scenes different from land scenes emotionally?
> 
> 

<!-- CM-CN _ 095-096 _ -->
- What creatures or forces live in the ocean, and what do they represent?
> 
> 

### The Little Mermaid
<!-- CM-CN _ 099-100 _ -->
- Is the ocean Ariel’s home or a prison?
> 
> 

<!-- CM-CN _ 101-102 _ -->
- How does the sea change when she leaves it?
> 
> 

<!-- CM-CN _ 103-104 _ -->
- Does the ocean feel empowering or limiting in this version?
> 
> 

### Your Cultural Self
<!-- CM-CN _ 107-108 _ -->
- What does the ocean mean in your own life or culture—vacation, myth, fear, ancestry?
> 
> 

<!-- CM-CN _ 109-110 _ -->
- Were you taught to respect, fear, or romanticize the sea?
> 
> 

<!-- CM-CN _ 111-112 _ -->
- Have you seen the ocean used symbolically in your cultural stories or media?
> 
> 

## Child Protagonists & Family Roles
### Ponyo
<!-- CM-CN _ 117-118 _ -->
- How do Sōsuke’s and Ponyo’s parents differ in their responses to crisis?
> 
> 

<!-- CM-CN _ 119-120 _ -->
- Is Fujimoto a villain or a protector? How do you know?
> 
> 

<!-- CM-CN _ 121-122 _ -->
- How does the story portray motherly care (e.g., Lisa) and responsibility?
> 
> 

### The Little Mermaid
<!-- CM-CN _ 125-126 _ -->
- How does King Triton’s authority affect Ariel’s choices?
> 
> 

<!-- CM-CN _ 127-128 _ -->
- How is family portrayed: as safety, control, or conflict?
> 
> 

<!-- CM-CN _ 129-130 _ -->
- Are parent-child relationships about rules or trust?
> 
> 

### Your Cultural Self
<!-- CM-CN _ 133-134 _ -->
- How did your family influence your ideas about love, danger, or independence?
> 
> 

<!-- CM-CN _ 135-136 _ -->
- Were stories in your culture more about respecting or escaping authority?
> 
> 

<!-- CM-CN _ 137-138 _ -->
- How were children expected to behave—obedient, curious, rebellious?
> 
> 
