# CC-01 – Full-Fidelity Myth Mirror & Story Lens

### Purpose:
Build cultural and symbolic self-awareness before textual analysis.

### Instructions:
Answer the following reflective questions. There are no right answers—be poetic, personal, or symbolic. Use this space to explore how stories have shaped your imagination.

## What kinds of stories shaped you?
<!-- CM-CN _ 005-006 _ -->
<!-- CM-CN _ 007-008 _ -->
- What movies, books, fairy tales, religious stories, or cultural legends shaped how you see the world?
<!-- CM-CN _ 009-010 _ -->
- Who are you in those stories? The hero? The watcher? The one who breaks the rules?
> 
> 

## What does the ocean mean to you?
<!-- CM-CN _ 011-012 _ -->
<!-- CM-CN _ 013-014 _ -->
- Have you ever lived near the water?
<!-- CM-CN _ 015-016 _ -->
- What have you been taught about the sea?
<!-- CM-CN _ 017-018 _ -->
- Is it a border, a memory, a freedom, a danger?
> 
> 

## What does transformation look like in your life?
<!-- CM-CN _ 019-020 _ -->
<!-- CM-CN _ 021-022 _ -->
- When have you changed? Who or what caused it?
<!-- CM-CN _ 023-024 _ -->
- Did it feel magical, painful, freeing, scary?
> 
> 

## What do you believe love should cost?
<!-- CM-CN _ 025-026 _ -->
<!-- CM-CN _ 027-028 _ -->
- In stories, love often requires sacrifice. Do you believe that’s fair?
<!-- CM-CN _ 029-030 _ -->
- What’s the most powerful love story you know?
> 
> 

## What do you fear or dislike in stories?
<!-- CM-CN _ 031-032 _ -->
<!-- CM-CN _ 033-034 _ -->
- Are there moments in movies or myths that make you uncomfortable?
<!-- CM-CN _ 035-036 _ -->
- Are there patterns that bother you—how girls are treated, how endings are wrapped up?
> 
> 

## Final Reflection
<!-- CM-CN _ 037-038 _ -->
- What kind of story *are you* most drawn to telling? <!-- CM-CN _ 039-040 _ -->
- Do you prefer balance or chaos? Resolution or ambiguity? <!-- CM-CN _ 041-042 _ -->
- What kind of “mirror” are you holding when you look at these two films? <!-- CM-CN _ 043-044 _ -->
> 
> 

## Symbolic Representation Box
Choose a visual, symbolic, or metaphorical way to express a major theme from either film.
- What object or shape represents the story’s transformation? <!-- CM-CN _ 045-046 _ -->
- What symbol reflects love, nature, or sacrifice? <!-- CM-CN _ 047-048 _ -->
> 
> 
