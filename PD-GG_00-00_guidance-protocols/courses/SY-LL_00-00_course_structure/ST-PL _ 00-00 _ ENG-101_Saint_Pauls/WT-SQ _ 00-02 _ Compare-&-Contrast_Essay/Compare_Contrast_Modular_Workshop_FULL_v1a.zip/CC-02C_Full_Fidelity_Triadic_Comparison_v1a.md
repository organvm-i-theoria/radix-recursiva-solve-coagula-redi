# CC-02C – Full-Fidelity Triadic Comparison (Blocks 4–10)

## Magic & Transformation
### Ponyo
<!-- CM-CN _ 143-144 _ -->
- Who controls magic, and how is it used or misused?
> 
> 

<!-- CM-CN _ 145-146 _ -->
- What changes in the world when Ponyo transforms?
> 
> 

<!-- CM-CN _ 147-148 _ -->
- Is transformation portrayed as liberating, risky, or both?
> 
> 

### The Little Mermaid
<!-- CM-CN _ 151-152 _ -->
- What is the price Ariel pays for transformation?
> 
> 

<!-- CM-CN _ 153-154 _ -->
- Is the magic portrayed as a curse, a deal, or a gift?
> 
> 

<!-- CM-CN _ 155-156 _ -->
- Who holds the power—Ariel, Ursula, or her father?
> 
> 

### Your Cultural Self
<!-- CM-CN _ 159-160 _ -->
- Have you encountered stories about transformation in your upbringing?
> 
> 

<!-- CM-CN _ 161-162 _ -->
- In those stories, was transformation empowering or punishing?
> 
> 

<!-- CM-CN _ 163-164 _ -->
- How does your culture view bodily or spiritual change?
> 
> 

## Conflict & Resolution
### Ponyo
<!-- CM-CN _ 169-170 _ -->
- What forces threaten the balance of the world?
> 
> 

<!-- CM-CN _ 171-172 _ -->
- How is harmony restored—through love, sacrifice, or understanding?
> 
> 

<!-- CM-CN _ 173-174 _ -->
- Who makes the final decision, and why?
> 
> 

### The Little Mermaid
<!-- CM-CN _ 177-178 _ -->
- What consequences does Ariel face for her choices?
> 
> 

<!-- CM-CN _ 179-180 _ -->
- Is the ending a reward, a consequence, or a compromise?
> 
> 

<!-- CM-CN _ 181-182 _ -->
- How is conflict between worlds portrayed?
> 
> 

### Your Cultural Self
<!-- CM-CN _ 185-186 _ -->
- How are conflicts usually resolved in stories you were told—by negotiation, punishment, escape?
> 
> 

<!-- CM-CN _ 187-188 _ -->
- Are happy endings expected, or do stories end in ambiguity?
> 
> 

<!-- CM-CN _ 189-190 _ -->
- What values are usually rewarded in your culture’s tales?
> 
> 

## Love & Relational Ethics
### Ponyo
<!-- CM-CN _ 195-196 _ -->
- What kind of love exists between Ponyo and Sōsuke?
> 
> 

<!-- CM-CN _ 197-198 _ -->
- Is their love physical, emotional, symbolic?
> 
> 

<!-- CM-CN _ 199-200 _ -->
- How does their love affect the world around them?
> 
> 

### The Little Mermaid
<!-- CM-CN _ 203-204 _ -->
- How is Ariel’s love for Eric portrayed?
> 
> 

<!-- CM-CN _ 205-206 _ -->
- What does she give up—and does he truly earn it?
> 
> 

<!-- CM-CN _ 207-208 _ -->
- Is love shown as destiny, choice, or fantasy?
> 
> 

### Your Cultural Self
<!-- CM-CN _ 211-212 _ -->
- What did love look like in stories you grew up with?
> 
> 

<!-- CM-CN _ 213-214 _ -->
- Were sacrifices for love encouraged or questioned?
> 
> 

<!-- CM-CN _ 215-216 _ -->
- Do you believe love is transformational?
> 
> 

## Ecological & Cosmic Worldview
### Ponyo
<!-- CM-CN _ 221-222 _ -->
- How does Ponyo’s magic affect natural forces?
> 
> 

<!-- CM-CN _ 223-224 _ -->
- What visual cues suggest environmental or cosmic imbalance?
> 
> 

<!-- CM-CN _ 225-226 _ -->
- What does the film suggest about human responsibility?
> 
> 

### The Little Mermaid
<!-- CM-CN _ 229-230 _ -->
- Does Ariel’s journey disrupt natural order?
> 
> 

<!-- CM-CN _ 231-232 _ -->
- Is the ocean ecosystem affected by her choices?
> 
> 

<!-- CM-CN _ 233-234 _ -->
- What is the film’s attitude toward the boundary between land and sea?
> 
> 

### Your Cultural Self
<!-- CM-CN _ 237-238 _ -->
- How do your culture’s stories treat nature—sacred, utilitarian, indifferent?
> 
> 

<!-- CM-CN _ 239-240 _ -->
- Are there myths about balance, chaos, or environmental harmony?
> 
> 

<!-- CM-CN _ 241-242 _ -->
- How have you personally experienced ecological teachings?
> 
> 

## Gender, Power, and Agency
### Ponyo
<!-- CM-CN _ 247-248 _ -->
- Is Ponyo’s desire for transformation her own or influenced by others?
> 
> 

<!-- CM-CN _ 249-250 _ -->
- How does Sōsuke treat Ponyo—protective, equal, passive?
> 
> 

<!-- CM-CN _ 251-252 _ -->
- What gender norms are reinforced or challenged?
> 
> 

### The Little Mermaid
<!-- CM-CN _ 255-256 _ -->
- Does Ariel have agency over her choices?
> 
> 

<!-- CM-CN _ 257-258 _ -->
- How is her voice used—literally and symbolically?
> 
> 

<!-- CM-CN _ 259-260 _ -->
- Are gender roles traditional or disrupted?
> 
> 

### Your Cultural Self
<!-- CM-CN _ 263-264 _ -->
- What gender roles were present in your cultural stories?
> 
> 

<!-- CM-CN _ 265-266 _ -->
- Were girls and boys given equal power in stories?
> 
> 

<!-- CM-CN _ 267-268 _ -->
- How has your understanding of gender and power evolved?
> 
> 

## Cultural Values (Implied and Explicit)
### Ponyo
<!-- CM-CN _ 273-274 _ -->
- What values are embedded in the story’s worldview (e.g., harmony, balance, innocence)?
> 
> 

<!-- CM-CN _ 275-276 _ -->
- How are elders, the sea, or nature treated?
> 
> 

<!-- CM-CN _ 277-278 _ -->
- What is the role of childhood and play?
> 
> 

### The Little Mermaid
<!-- CM-CN _ 281-282 _ -->
- What messages are implied about individuality and rebellion?
> 
> 

<!-- CM-CN _ 283-284 _ -->
- Is upward mobility (from sea to land) a metaphor?
> 
> 

<!-- CM-CN _ 285-286 _ -->
- What values are taught about authority, desire, and destiny?
> 
> 

### Your Cultural Self
<!-- CM-CN _ 289-290 _ -->
- What values did stories you grew up with emphasize?
> 
> 

<!-- CM-CN _ 291-292 _ -->
- How are children taught about obedience, freedom, and consequence?
> 
> 

<!-- CM-CN _ 293-294 _ -->
- Are your culture’s stories moral, ironic, tragic, or celebratory?
> 
> 

## Final Moral or Philosophical Takeaway
### Ponyo
<!-- CM-CN _ 299-300 _ -->
- What emotional state does the film end on?
> 
> 

<!-- CM-CN _ 301-302 _ -->
- Is the final message about love, nature, or destiny?
> 
> 

<!-- CM-CN _ 303-304 _ -->
- What *isn’t* resolved—and why might that matter?
> 
> 

### The Little Mermaid
<!-- CM-CN _ 307-308 _ -->
- Is the ending fulfilling or problematic?
> 
> 

<!-- CM-CN _ 309-310 _ -->
- Who gets what they want—and who sacrifices?
> 
> 

<!-- CM-CN _ 311-312 _ -->
- What world has been created or destroyed by the end?
> 
> 

### Your Cultural Self
<!-- CM-CN _ 315-316 _ -->
- What kinds of endings do you find meaningful or frustrating?
> 
> 

<!-- CM-CN _ 317-318 _ -->
- Do stories need closure in your tradition?
> 
> 

<!-- CM-CN _ 319-320 _ -->
- What moral would *you* take from both versions?
> 
> 
